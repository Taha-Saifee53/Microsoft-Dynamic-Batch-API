package com.quantum.adaptorPOC;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author Taha Saifee
 * This class reads the properties file from the resource package.
 */

public class AdaptorProperties {
	
	private static Properties application = new Properties();
	static {
		String applicationprops = "application.properties";
		InputStream inputStream = AdaptorProperties.class.getClassLoader().getResourceAsStream(applicationprops);

		if (inputStream != null) {
			try {
				application.load(inputStream);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else {
			try {
				throw new FileNotFoundException("property file not found in the classpath");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/**
	 * This Method return the properties value.
	 * @param String input
	 */
	public static String getApplicationProperties(String input){
		
		return application.getProperty(input);
		
		}
}

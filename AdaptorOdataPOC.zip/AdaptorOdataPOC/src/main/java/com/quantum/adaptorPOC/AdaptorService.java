package com.quantum.adaptorPOC;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.quantum.getAdaptor.GetRequestGenerator;
import com.quantum.getAdaptor.GetResponseGenerator;
import com.quantum.postAdaptor.PostRequestGenerator;
import com.quantum.postAdaptor.PostResponseGenerator;
import com.quantum.utils.AdaptorErrorHandler;

/**
 * @author Taha Saifee
 * This class receives the request for OData batch invocation. This class exposes separate functions for Odata batch call for HTTP GET and POST. It also sends the response back to its invoker in JSON format.
 */
@RestController
public class AdaptorService {
	
	public static final String BOUNDARY = "batch_123";

	/* @GET Method Batch Operation */
	/* @Throws IOException if IO error occurs
	 * @Webservice to invoke GET method /odataadapter/ 
	 * @Webservice to invoke GET method /odataadapter/transactions */

	/**
	 * This method receives the GET request in JSON format and sends back the response in JSON format. 
	 * @throws IOException if IO error occurs
	 * @GET /odataadapter/ Method Batch Operation
	 * @param HttpServletRequest request*/
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/odataadapter/", consumes = "application/json", method = RequestMethod.GET)
	public JSONObject adaptorGetRequest(HttpServletRequest req) throws IOException {
		
		 
		// method body
		GetRequestGenerator getReqAdap = new GetRequestGenerator();
		String reqBody = IOUtils.toString(req.getReader());
		JSONObject generatedResponse = null;
		JSONObject errMsg = new JSONObject();
		// GetResponseGenerator getRespAdap = new GetResponseGenerator();
		// JSONObject resp = getRespAdap.generateResponse();
		try {
			String generatedRequest = getReqAdap.generateRequest(reqBody);
			// System.out.println(reqBody);
			String contentType = "multipart/mixed;boundary=" + BOUNDARY;
			StringBuffer response = new StringBuffer();

			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			} };

			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// System.out.println("Bear"+req.getParameter("token"));
			String Authorization = "Bearer " + req.getParameter("token");
			String sapURL = AdaptorProperties.getApplicationProperties("sapUrl");
			URL url = new URL(sapURL);
			System.out.println("Hii");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Authorization", req.getHeader("Authorization"));
			conn.setRequestProperty("Connection", "Keep-Alive");
			conn.setRequestProperty("Content-Type", contentType);
			conn.setDoOutput(true);

			// int responseCode = conn.getResponseCode();
			// System.out.println(responseCode);
			conn.connect();
			// OutputStream os = conn.getOutputStream();
			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			System.out.println("input parameters" + generatedRequest.toString().getBytes());
			wr.write(generatedRequest);

			wr.flush();
			wr.close();
			int responseCode = conn.getResponseCode();
			System.out.println("Response code" + responseCode);
			// System.out.println(conn.getHeaderFields().get("OData-EntityId"));
			// System.out.println(conn.getHeaderFields().get("Content-Type"));
			// System.out.println(conn.getResponseMessage());
			/*
			 * BufferedReader in = new BufferedReader(new
			 * InputStreamReader(conn.getInputStream())); String inputLine;
			 */
			String resp = IOUtils.toString(conn.getInputStream());
			// System.out.println(resp);
			GetResponseGenerator getRespAdap = new GetResponseGenerator();
			generatedResponse = getRespAdap.generateResponse(resp, conn);
			/*
			 * while ((inputLine = in.readLine()) != null) { response.append(inputLine); }
			 */
			// System.out.println(response.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection failed");
			e.printStackTrace();
			errMsg.put("ErrorMsg", e.toString());
			System.out.println(errMsg.toString());
			return errMsg;
		} catch (Exception e) {
			// TODO: handle exception
			errMsg.put("ErrorMsg", e.toString());
			System.out.println(errMsg.toString());
			return errMsg;
		}

		return generatedResponse;

	}
	
	
	/* @POST Method Batch Operation */
	/* @Throws IOException if IO error occurs*/
	/**
	 * This method receives the POST request in JSON format and sends back the response in JSON format. 
	 * @throws IOException if IO error occurs
	 * @POST /odataadapter/transactions Method Batch Operation
	 * @param HttpServletRequest request*/
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/odataadapter/transactions", consumes = "application/json", method = RequestMethod.POST)
	public JSONObject adaptorPostRequest(HttpServletRequest req) throws IOException {
		//method body
		
		JSONObject genRes = null;
		PostRequestGenerator getAdapReq = new PostRequestGenerator();
		String reqBody = IOUtils.toString(req.getReader());
		String generatedRequest = null;
		JSONObject errMsg = new JSONObject();
		try {
			generatedRequest = getAdapReq.generateRequestPost(reqBody);

			String contentType = "multipart/mixed;boundary=" + BOUNDARY;

			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			} };
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			String Authorization = "Bearer "+req.getParameter("token");
			//String Authorization = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Indvelg1dWRlYmFuY01sbXpiUkpOTWFTSkRqOCJ9.eyJhdWQiOiJodHRwczovL3F1YW50dW10LndpcHJvLmNvbS9hcGkvZGF0YS92OS4wLyIsImlzcyI6Imh0dHA6Ly93aXBmc3VhdC53aXByby5jb20vYWRmcy9zZXJ2aWNlcy90cnVzdCIsImlhdCI6MTU1OTAzMzQyNiwiZXhwIjoxNTU5MDM3MDI2LCJ1cG4iOiJzYTQwMDI1NzQzQHdpcHJvLmNvbSIsInByaW1hcnlzaWQiOiJTLTEtNS0yMS01Nzk4OTg0MS02MTYyNDkzNzYtMTgwMTY3NDUzMS0yNjI4NzgxIiwidW5pcXVlX25hbWUiOlsiV0lQUk9cXFNBNDAwMjU3NDMiLCJTYW50b3NoIEt1bWFyIEJlaGVyYSAoQ0lPIE9mZmljZSkiLCJTQTQwMDI1NzQzQHdpcHJvLmNvbSJdLCJzdWIiOiI0MDAyNTc0MyIsImdpdmVuX25hbWUiOiJTYW50b3NoIEt1bWFyIEJlaGVyYSAoQ0lPIE9mZmljZSkiLCJlbWFpbCI6InNhbnRvc2guYmVoZXJhM0B3aXByby5jb20iLCJhcHB0eXBlIjoiQ29uZmlkZW50aWFsIiwiYXBwaWQiOiIyMWZhZDdmOC0yMGZkLTQ4ZmItOGY4OC03YmIzMDZhOWY4ZjQiLCJhdXRobWV0aG9kIjoidXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFjOmNsYXNzZXM6UGFzc3dvcmRQcm90ZWN0ZWRUcmFuc3BvcnQiLCJhdXRoX3RpbWUiOiIyMDE5LTA1LTI4VDA0OjU5OjA2LjU5MVoiLCJ2ZXIiOiIxLjAifQ.gz4TjenH2F3SrDyTLlAJJM7e0L7Q1ssgSGC5LE9DwG-p10KR0NImEKKYJyFuFK93KNkz09i9_rOMbNz96DDjRqzw9bcx5tyAS7sohDFYcOJHsv0T-TIydhPLdhhJ9TaIg6CTV4zG06jRXzQm0fdFiXzQaN0mYvvXbmeT77WYzMxVqMSRgsbR_W4EFAzxAO0E6N_g_a283BtEmz6uVp5sx2BucsalZInW4piTqAyrgsMkHC08r-fnep8a4C3QMGVnOkWT9BD_6_XdDzsB6B30omhQ4vt7_G-exlpjiovDeKBSx5B4q3CIN-bHNBR_9o-zuqQRIO1sGKlUADLYCwdn8g";
			String sapURL = AdaptorProperties.getApplicationProperties("sapUrl");
			URL url = new URL(sapURL);
			System.out.println("Hii");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			System.out.println("Auth"+Authorization);
			System.out.println(req.getHeader("Authorization"));
			conn.setRequestProperty("Authorization", req.getHeader("Authorization"));
			conn.setRequestProperty("Connection", "Keep-Alive");
			conn.setRequestProperty("Content-Type", contentType);
			conn.setDoOutput(true);
			// int responseCode = conn.getResponseCode();
			// System.out.println(responseCode);
			conn.connect();
			// OutputStream os = conn.getOutputStream();
			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			System.out.println("input parameters" + generatedRequest.toString().getBytes());
			wr.write(generatedRequest);

			wr.flush();
			wr.close();
			int responseCode = conn.getResponseCode();
			System.out.println("Response code" + responseCode);
			System.out.println(conn.getHeaderFields().get("OData-EntityId"));
			System.out.println(conn.getHeaderFields().get("Content-Type"));
			System.out.println(conn.getResponseMessage());
			/*
			 * BufferedReader in = new BufferedReader(new
			 * InputStreamReader(conn.getInputStream())); String inputLine;
			 */
			String resp = IOUtils.toString(conn.getInputStream());
			//System.out.println(resp);
			
			PostResponseGenerator getResPost = new PostResponseGenerator();
			genRes = getResPost.generateResponse(resp, conn);
			System.out.println(genRes);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection failed");
			e.printStackTrace();
		} catch (Exception e) {
			errMsg.put("ErrorMsg", e.toString());
			return errMsg;
		}
		return genRes;
	}

}
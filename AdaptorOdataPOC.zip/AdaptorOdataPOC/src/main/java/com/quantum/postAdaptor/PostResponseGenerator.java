package com.quantum.postAdaptor;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.List;

import org.apache.olingo.odata2.api.batch.BatchException;
import org.apache.olingo.odata2.api.client.batch.BatchSingleResponse;
import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * This class receives the response of OData batch. This class is responsible to generate the POST JSON format response from OData response Batch.
 */
public class PostResponseGenerator {

	/**
	 * @throws Exception if Olingo library fails to generate the request
	 * @Generate the JSON transaction response
	 */
	/**
	 * This method is responsible to generate the JSON format response from OData batch response. This method return JSONObject.
	 * @throws Exception if Olingo library fails to generate the request
	 * @param String getResponse
	 * @param HttpURLConnection conn
	 * @return JSONObject postJsonRespopnse
	 */
	@SuppressWarnings("unchecked")
	public JSONObject generateResponse(String getResponse, HttpURLConnection conn) throws Exception {

		
		// method body
		System.out.println("Response Receive : " + getResponse);
		String batchStart = conn.getHeaderFields().get("Content-Type") + "";
		System.out.println(batchStart.substring(27, batchStart.length() - 1));

		/*
		 * String resp = "--batchresponse_cac22186-986a-413b-be58-b37053c502d9\r\n" +
		 * "Content-Type: multipart/mixed; boundary=changesetresponse_6bb97a4b-d036-4714-9e78-74e3fcab39b7\r\n"
		 * + "\r\n" + "--changesetresponse_6bb97a4b-d036-4714-9e78-74e3fcab39b7\r\n" +
		 * "Content-Type: application/http\r\n" +
		 * "Content-Transfer-Encoding: binary\r\n" + "Content-ID: 1\r\n" + "\r\n" +
		 * "HTTP/1.1 204 No Content\r\n" + "OData-Version: 4.0\r\n" +
		 * "Location: https://quantumt.wipro.com/api/data/v9.0/wipro_prospects(97c3c3bb-5680-e911-a831-000d3aa058cb)\r\n"
		 * +
		 * "OData-EntityId: https://quantumt.wipro.com/api/data/v9.0/wipro_prospects(97c3c3bb-5680-e911-a831-000d3aa058cb)\r\n"
		 * + "\r\n" + "\r\n" +
		 * "--changesetresponse_6bb97a4b-d036-4714-9e78-74e3fcab39b7--\r\n" +
		 * "--batchresponse_cac22186-986a-413b-be58-b37053c502d9--\r\n" + "";
		 */
		JSONObject jsonObject = null;
		JSONArray finalArray = new JSONArray();
		JSONArray jsonArray = new JSONArray();
		JSONObject finalObject = new JSONObject();
		JSONObject jsonRes = new JSONObject();
		String[] changeSet = getResponse.split("--" + batchStart.substring(27, batchStart.length() - 1));
		System.out.println(changeSet.length);
		try {
			for (int changeItr = 1; changeItr < changeSet.length - 1; changeItr++) {
				String changeSetPart = "--batch_123" + changeSet[changeItr] + "--batch_123--";
				System.out.println(changeSet);
				InputStream inc = new ByteArrayInputStream(changeSetPart.getBytes());
				List<BatchSingleResponse> batch1 = EntityProvider.parseBatchResponse(inc,
						"multipart/mixed;boundary=batch_123");
				jsonArray = new JSONArray();
				jsonRes = new JSONObject();
				// jsonObject = new JSONObject();
				for (int batchSize = 0; batchSize < batch1.size(); batchSize++) {
					jsonObject = new JSONObject();
					BatchSingleResponse response = batch1.get(batchSize);
					jsonObject.put("id", response.getContentId());
					System.out.println(response.getContentId());
					jsonObject.put("http_status_code", response.getStatusCode());
					jsonObject.put("http_status_info", response.getStatusInfo());
					jsonObject.put("odata_entity_id", response.getHeaders().get("OData-EntityId"));
					jsonObject.put("location", response.getHeaders().get("Location"));
					if (response.getBody().length() != 0) {
						System.out.println(response.getBody().length());
						jsonObject.put("body", response.getBody());
					}
					jsonArray.add(jsonObject);
				}
				System.out.println(jsonArray.toJSONString());
				// jsonObject = new JSONObject();
				jsonRes.put("responses", jsonArray);
				System.out.println(jsonRes);
				finalArray.add(jsonRes);

				System.out.println("FinalArray :" + finalArray.toString());
				// jsonArray.clear();
			}
			System.out.println(finalArray.toString());
			finalObject.put("transactions", finalArray);
			System.out.println(finalObject);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return finalObject;

	}

}

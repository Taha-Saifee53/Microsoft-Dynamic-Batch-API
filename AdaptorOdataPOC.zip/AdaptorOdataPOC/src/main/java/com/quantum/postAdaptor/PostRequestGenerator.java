package com.quantum.postAdaptor;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.olingo.odata2.api.client.batch.BatchChangeSet;
import org.apache.olingo.odata2.api.client.batch.BatchChangeSetPart;
import org.apache.olingo.odata2.api.client.batch.BatchPart;
import org.apache.olingo.odata2.core.batch.BatchRequestWriter;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.quantum.utils.AdaptorErrorHandler;

/**
 * This class receives the JSON format request. This class is responsible to generate the POST OData batch request.
 */
public class PostRequestGenerator {
	
	/** @Generate Batch Request for POST transaction
	 * @throws AdaptorErrorHandler if the transaction request contains GET method
	 */
	
	public static final String BOUNDARY = "batch_123";
	/**
	 * This method receives the JSON request from AdaptorService class and generate OData batch request. This method return OData POST request. 
	 * @throws AdaptorErrorHandler if the transaction request contains GET method
	 * @param String jsonRequestBody
	 * @return String postBatchRequest
	 * */
	public String generateRequestPost(String reqBody) throws AdaptorErrorHandler {
		
		
		//method body
		String result = null;
		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArrayInner = new JSONArray();
		String body;
		try {
			jsonObject = (JSONObject) jsonParser.parse(reqBody);
			body = jsonObject.get("transactions")+"";
			jsonArray = (JSONArray) jsonParser.parse(body);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String requestJson;
		List<BatchPart> batch = new ArrayList<BatchPart>();
		for(int jsonMain=0; jsonMain<jsonArray.size();jsonMain++) {
			
			System.out.println("check"+jsonMain);
			try {
				jsonObject = (JSONObject) jsonParser.parse(jsonArray.get(jsonMain)+"");
				requestJson = jsonObject.get("requests")+"";
				jsonArrayInner = (JSONArray) jsonParser.parse(requestJson);
				System.out.println(jsonArrayInner);
				
				BatchChangeSet changeSet = BatchChangeSet.newBuilder().build();
				BatchChangeSetPart changeRequest;
				for (int readJson = 0; readJson < jsonArrayInner.size(); readJson++) {
					System.out.println("innerArray"+jsonArrayInner.size());
					Map<String, String> changeSetPartHeader = new HashMap<String, String>();
					String innerBody = "";
					innerBody = jsonArrayInner.get(readJson) + "";
					System.out.println(innerBody);
					try {
						jsonObject=(JSONObject) jsonParser.parse(innerBody);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println(jsonObject.get("url"));
					String Service_URL = jsonObject.get("url")+"";
					System.out.println(jsonObject.get("operation"));
					String operation = jsonObject.get("operation").toString();
					String message_body = jsonObject.get("body")+"";
					//message_body = message_body.substring(1,message_body.length()-1);
					String contentID = jsonObject.get("id")+"";
					System.out.println(contentID);
					changeSetPartHeader.put("Content-Type", "application/json;type=entry");
					if(null!=operation && operation.equalsIgnoreCase("GET")) {
						throw new AdaptorErrorHandler();
						
					}else {
						changeRequest = BatchChangeSetPart.method(operation).uri(Service_URL).contentId(contentID).body(message_body)
								.headers(changeSetPartHeader).build();
						//changeSet = 
						changeSet.add(changeRequest);
					}
					

				}
				batch.add(changeSet);
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		BatchRequestWriter writer = new BatchRequestWriter();
		InputStream batchRequest = writer.writeBatchRequest(batch, BOUNDARY);
		try {
			//System.out.println(IOUtils.toString(batchRequest));
			batchRequest.toString();
			result = IOUtils.toString(batchRequest);
			System.out.println(result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}

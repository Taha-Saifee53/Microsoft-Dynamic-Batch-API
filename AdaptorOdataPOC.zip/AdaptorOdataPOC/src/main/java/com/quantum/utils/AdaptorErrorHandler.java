package com.quantum.utils;

/** Generate exception if GET method is present in POST transaction
 * */
public class AdaptorErrorHandler extends Exception {
	
	
	private static final long serialVersionUID = 1L;

	/**
	 * @return String Invalid POST JSON Request
	 */
	public String toString() {
		
		//method body
		return "Invalid POST Request";
	}

}
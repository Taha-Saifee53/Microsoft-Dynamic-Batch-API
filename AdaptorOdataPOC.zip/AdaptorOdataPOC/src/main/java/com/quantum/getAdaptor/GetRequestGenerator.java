package com.quantum.getAdaptor;

import java.awt.PageAttributes.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.print.attribute.standard.Media;

import org.apache.commons.io.IOUtils;
import org.apache.olingo.commons.api.http.HttpMethod;
import org.apache.olingo.odata2.api.batch.BatchException;
import org.apache.olingo.odata2.api.client.batch.BatchChangeSet;
import org.apache.olingo.odata2.api.client.batch.BatchChangeSetPart;
import org.apache.olingo.odata2.api.client.batch.BatchPart;
import org.apache.olingo.odata2.api.client.batch.BatchQueryPart;
import org.apache.olingo.odata2.api.commons.ODataHttpMethod;
import org.apache.olingo.odata2.core.batch.BatchRequestWriter;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * This class receives the JSON format request. This class is responsible to generate the GET OData batch request.
 */
public class GetRequestGenerator {

	public static final String BOUNDARY = "batch_123";

	
	/* @throws BatchException if it fails to generate the batch request
	 * @throws Exception if I/O error occurs
	 * @Generate GET Batch request*/
	/**
	 * This method receives the JSON request from AdaptorService class and generate OData batch request. This method return OData GET request. 
	 * @throws BatchException if it fails to generate the batch request
	 * @throws Exception if I/O error occurs
	 * @param String JSONrequest
	 * @return String generatedBatchRequest*/
	public String generateRequest(String req) throws Exception, BatchException{
		
		//method body
		String result = null;
		String content_Type = "multipart/mixed;boundary=" + BOUNDARY;
		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArrayInner = new JSONArray();
		String body;
		/*try {
			jsonObject = (JSONObject) jsonParser.parse(req);
			body = jsonObject.get("transactions") + "";
			jsonArray = (JSONArray) jsonParser.parse(body);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		String requestJson;
		List<BatchPart> batch = new ArrayList<BatchPart>();
		BatchPart batchRequest = null;
		//for (int jsonMain = 0; jsonMain < jsonArray.size(); jsonMain++) {

			//System.out.println("check" + jsonMain);
			try {
				//jsonObject = (JSONObject) jsonParser.parse(jsonArray.get(jsonMain) + "");
				jsonObject = (JSONObject) jsonParser.parse(req);
				requestJson = jsonObject.get("requests") + "";
				jsonArrayInner = (JSONArray) jsonParser.parse(requestJson);
				System.out.println(jsonArrayInner);

				BatchChangeSet changeSet = BatchChangeSet.newBuilder().build();
				BatchChangeSetPart changeRequest;
				BatchPart changeRequestGet;
				for (int readJson = 0; readJson < jsonArrayInner.size(); readJson++) {
					System.out.println("innerArray" + jsonArrayInner.size());
					Map<String, String> changeSetPartHeader = new HashMap<String, String>();
					String innerBody = "";
					innerBody = jsonArrayInner.get(readJson) + "";
					System.out.println(innerBody);
					try {
						jsonObject = (JSONObject) jsonParser.parse(innerBody);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println(jsonObject.get("url"));
					String Service_URL = jsonObject.get("url") + "";
					System.out.println(jsonObject.get("operation"));
					String operation = jsonObject.get("operation").toString();
					String message_body = jsonObject.get("body") + "";
					String contentID = jsonObject.get("id") + "";
					System.out.println(contentID);
					changeSetPartHeader.put("Content-Type", "application/json;type=entry");
					
					changeRequestGet = BatchQueryPart.method(operation).uri(Service_URL).contentId(contentID)
							.headers(changeSetPartHeader).build();
					// changeSet =
					
					batch.add(changeRequestGet);
					/*changeRequest = BatchChangeSetPart.method("POST").uri(Service_URL).contentId(contentID)
							.headers(changeSetPartHeader).build();
					//changeSet = 
					changeSet.add(changeRequest);*/
					
				}
				//batch.add(changeSet);
				

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//}
		BatchRequestWriter writer = new BatchRequestWriter();
		InputStream batchRequestWriter = writer.writeBatchRequest(batch, BOUNDARY);
		try {
			// System.out.println(IOUtils.toString(batchRequest));
			//batchRequest.toString();
			result = IOUtils.toString(batchRequestWriter);
			System.out.println(result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

	}

}
